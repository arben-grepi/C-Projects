﻿namespace Harjoitustyö
{

    public class Laskuttaja
    {
        public string Nimi;
        public string Osoite;
        public Laskuttaja()
        {
            Nimi = string.Empty;
            Osoite = string.Empty;


        }
    }
}

