﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Harjoitustyö
{
    /// <summary>
    /// Interaction logic for Valitse_asiakas.xaml
    /// </summary>
    public partial class Valitse_asiakas : Window
    {
        public Valitse_asiakas()
        {
            InitializeComponent();
        }
    }
}
